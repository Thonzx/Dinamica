import unittest
from src.math_operations import add

class TestMathOperations(unittest.TestCase):
    def test_add_basic(self):
        self.assertEqual(add(2, 3), 5)  # Testa soma básica

    def test_add_with_zero(self):
        self.assertEqual(add(0, 0), 0)  # Soma com zero
        self.assertEqual(add(5, 0), 5)  # Soma com zero em um lado

    def test_add_negative_numbers(self):
        self.assertEqual(add(-2, -3), -5)  # Soma com números negativos
        self.assertEqual(add(-2, 3), 1)   # Soma de negativo com positivo

    def test_add_large_numbers(self):
        self.assertEqual(add(1000000, 2000000), 3000000)  # Testa números grandes

    def test_subtraction(self):
        self.assertNotEqual(add(2, 3), -1)  # Para cobrir o mutante

if __name__ == "__main__":
    unittest.main()
