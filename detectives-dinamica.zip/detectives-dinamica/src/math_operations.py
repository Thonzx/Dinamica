def add(a, b):
    return a + b  # Mutante: return a - b

def multiply(a, b):
    return a * b  # Esta linha também será alvo da mutação